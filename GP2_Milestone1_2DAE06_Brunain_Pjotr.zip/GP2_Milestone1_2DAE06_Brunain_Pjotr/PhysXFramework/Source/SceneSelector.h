#pragma once
class SceneManager;
namespace dae
{
	void AddScenes(SceneManager *pSceneManager);
};

